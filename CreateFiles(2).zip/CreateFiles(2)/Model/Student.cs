﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreateFiles.Model
{

    // 注意: 生成的代码可能至少需要 .NET Framework 4.5 或 .NET Core/Standard 2.0。
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class ArrayOfStudent
    {

        private Student[] studentField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Student")]
        public Student[] Student
        {
            get
            {
                return this.studentField;
            }
            set
            {
                this.studentField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class Student
    {

        private string studentIdField;

        private string firstNameField;

        private string lastNameField;

        private string studentCodeField;

        private bool myRecordField;

        private System.DateTime dateOfBirthField;

        private System.DateTime createDateField;

        private System.DateTime editDateField;

        /// <remarks/>
        public string StudentId
        {
            get
            {
                return this.studentIdField;
            }
            set
            {
                this.studentIdField = value;
            }
        }

        /// <remarks/>
        public string FirstName
        {
            get
            {
                return this.firstNameField;
            }
            set
            {
                this.firstNameField = value;
            }
        }

        /// <remarks/>
        public string LastName
        {
            get
            {
                return this.lastNameField;
            }
            set
            {
                this.lastNameField = value;
            }
        }

        /// <remarks/>
        public string StudentCode
        {
            get
            {
                return this.studentCodeField;
            }
            set
            {
                this.studentCodeField = value;
            }
        }

        /// <remarks/>
        public bool MyRecord
        {
            get
            {
                return this.myRecordField;
            }
            set
            {
                this.myRecordField = value;
            }
        }

        /// <remarks/>
        public System.DateTime DateOfBirth
        {
            get
            {
                return this.dateOfBirthField;
            }
            set
            {
                this.dateOfBirthField = value;
            }
        }

        /// <remarks/>
        public System.DateTime CreateDate
        {
            get
            {
                return this.createDateField;
            }
            set
            {
                this.createDateField = value;
            }
        }

        /// <remarks/>
        public System.DateTime EditDate
        {
            get
            {
                return this.editDateField;
            }
            set
            {
                this.editDateField = value;
            }
        }
    }


}
