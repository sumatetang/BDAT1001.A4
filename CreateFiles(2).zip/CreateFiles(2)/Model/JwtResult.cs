﻿namespace CreateFiles.Model
{
    class JwtResult
    {
        public string AccessToken { get; set; }
        public string ExpiresOn { get; set; }
    }
}
