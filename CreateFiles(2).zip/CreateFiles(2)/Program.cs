﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using CreateFiles.Api;
using CreateFiles.Model;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using Newtonsoft.Json; // using DocumentFormat.OpenXml;
// using DocumentFormat.OpenXml.Packaging;
// using DocumentFormat.OpenXml.Spreadsheet;
// using DocumentFormat.OpenXml.Wordprocessing;
// using A = DocumentFormat.OpenXml.Drawing;
// using Break = DocumentFormat.OpenXml.Wordprocessing.Break;
// using Drawing = DocumentFormat.OpenXml.Wordprocessing.Drawing;
// using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
// using PIC = DocumentFormat.OpenXml.Drawing.Pictures;
// using Run = DocumentFormat.OpenXml.Wordprocessing.Run;
// using Text = DocumentFormat.OpenXml.Wordprocessing.Text;
using A = DocumentFormat.OpenXml.Drawing;
using Break = DocumentFormat.OpenXml.Wordprocessing.Break;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;
using Run = DocumentFormat.OpenXml.Wordprocessing.Run;
using Text = DocumentFormat.OpenXml.Wordprocessing.Text;

namespace CreateFiles
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // WordHelper.InsertAPicture(Constants.DocumentFileName, Constants.ImageFileName);
            // InsertAPicture(Constants.DocumentFileName, Constants.ImageFileName);
            // return;

            var users = GetUsers();

            CreateWordDocument(users);

            // Upload docx file to FTP server.
            // var result = FTP.UploadFile(Constants.DocumentFileName, $"{Constants.FTP.MyDirectory}/info.docx");
            var result = FTP.UploadFile(Constants.DocumentFileName,
                $"{Constants.FTP.MyDirectory}/{Constants.DocumentFileName}");
            Console.WriteLine($"Upload  - {result}");


            var students = GetStudents();
            CreateSpreadsheetWorkbook(Constants.SpreadsheetFileName);
            AddStudentListToSpreadsheet(Constants.SpreadsheetFileName, students);
            result = FTP.UploadFile(Constants.SpreadsheetFileName,
                $"{Constants.FTP.MyDirectory}/{Constants.SpreadsheetFileName}");
            Console.WriteLine($"Upload  - {result}");
        }

        private static ArrayOfStudent GetStudents()
        {
            ArrayOfStudent students;

            var serializer = new XmlSerializer(typeof(ArrayOfStudent));
            using (var reader = new StreamReader("students.xml"))
            {
                students = (ArrayOfStudent) serializer.Deserialize(reader);
            }

            return students;
        }

        private static void CreateWordDocument(List<User> users)
        {
            // Create a document by supplying the filepath. 
            using (var wordDocument =
                WordprocessingDocument.Create(Constants.DocumentFileName, WordprocessingDocumentType.Document))
            {
                // Add a main document part. 
                var mainPart = wordDocument.AddMainDocumentPart();

                // Create the document structure and add some text.
                mainPart.Document = new Document();
                var body = mainPart.Document.AppendChild(new Body());

                foreach (var user in users)
                {
                    var para = body.AppendChild(new Paragraph());
                    var run = para.AppendChild(new Run());
                    run.AppendChild(new Text($"Name: {user.name}"));
                    body.Append(new Paragraph(
                        new Run(
                            new Break {Type = BreakValues.Page})));
                }

                // WordHelper.InsertAPicture(wordDocument, mainPart, Constants.ImageFileName);
            }

            WordHelper.InsertAPicture(Constants.DocumentFileName, Constants.ImageFileName);
        }

        private static List<User> GetUsers()
        {
            //Read the json from WebRequest
            var jsonWebRequestContent = HTTP.URLRequest(Constants.JsonPlaceholderUrl);
            var users = JsonConvert.DeserializeObject<List<User>>(jsonWebRequestContent);
            return users;
        }

        private static void CreateSpreadsheetWorkbook(string filepath)
        {
            // Create a spreadsheet document by supplying the filepath.
            // By default, AutoSave = true, Editable = true, and Type = xlsx.
            var spreadsheetDocument = SpreadsheetDocument.Create(filepath, SpreadsheetDocumentType.Workbook);

            // Add a WorkbookPart to the document.
            var workbookPart = spreadsheetDocument.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();

            // Add a WorksheetPart to the WorkbookPart.
            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            worksheetPart.Worksheet = new Worksheet(new SheetData());

            // Add Sheets to the Workbook.
            var sheets = spreadsheetDocument.WorkbookPart.Workbook.AppendChild(new Sheets());

            // Append a new worksheet and associate it with the workbook.
            var sheet = new Sheet
            {
                Id = spreadsheetDocument.WorkbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = "mySheet"
            };
            sheets.Append(sheet);

            SetCellText("A",
                2,
                Constants.MyName,
                workbookPart,
                worksheetPart);

            workbookPart.Workbook.Save();
            spreadsheetDocument.Close();
        }

        private static void SetCellText(string columnName, uint rowIndex, string text, WorkbookPart workbookPart,
            WorksheetPart worksheetPart)
        {
            var cell = ExcelHelper.InsertCellInWorksheet(columnName, rowIndex, worksheetPart);
            //创建多个工作表可共用的字符串容器
            var shareStringPart = ExcelHelper.CreateSharedStringTablePart(workbookPart);

            //在共用字符串容器里插入一个字符串
            var strIndex = ExcelHelper.InsertSharedStringItem(text, shareStringPart);

            //设置单元格的"值"
            cell.DataType = new EnumValue<CellValues>(CellValues.SharedString);
            cell.CellValue = new CellValue(strIndex.ToString()); //注：这里要设置为目标字符串在SharedStringTablePart中的索引
        }

        private static void SetCellFormula(string columnName, uint rowIndex, string fomular, WorkbookPart workbookPart,
            WorksheetPart worksheetPart)
        {
            var cell = ExcelHelper.InsertCellInWorksheet(columnName, rowIndex, worksheetPart);
            cell.Append(new CellFormula {Text = fomular});
        }

        private static void AddStudentListToSpreadsheet(string filepath, ArrayOfStudent students)
        {
            // Create a spreadsheet document by supplying the filepath.
            // By default, AutoSave = true, Editable = true, and Type = xlsx.
            var spreadsheetDocument = SpreadsheetDocument.Open(filepath, true);

            // Add a WorkbookPart to the document.
            var workbookPart = spreadsheetDocument.WorkbookPart;
            var sheet = ExcelHelper.InsertWorksheet(workbookPart, "Student List");

            SetCellText("A", 1, "StudentId", workbookPart, sheet);
            SetCellText("B", 1, "StudentCode", workbookPart, sheet);
            SetCellText("C", 1, "FirstName", workbookPart, sheet);
            SetCellText("D", 1, "LastName", workbookPart, sheet);
            SetCellText("E", 1, "DateOfBirth", workbookPart, sheet);
            SetCellText("F", 1, "IsMe", workbookPart, sheet);
            SetCellText("G", 1, "Age", workbookPart, sheet);

            uint row = 2;
            foreach (var student in students.Student)
            {
                SetCellText("A", row, student.StudentId, workbookPart, sheet);
                SetCellText("B", row, student.StudentCode, workbookPart, sheet);
                SetCellText("C", row, student.FirstName, workbookPart, sheet);
                SetCellText("D", row, student.LastName, workbookPart, sheet);
                SetCellText("E", row, student.DateOfBirth.ToString(), workbookPart, sheet);
                SetCellText("F", row, student.MyRecord ? "1" : "0", workbookPart, sheet);
                SetCellFormula("G", row, $"=RIGHT(YEAR(TODAY()-E{row}),2)", workbookPart, sheet);
                row++;
            }

            workbookPart.Workbook.Save();
            spreadsheetDocument.Close();
        }
    }
}